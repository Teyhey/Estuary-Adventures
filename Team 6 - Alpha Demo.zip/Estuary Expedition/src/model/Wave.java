package model;

public class Wave {

	public Wave() {
		// TODO Auto-generated constructor stub
	}

}
