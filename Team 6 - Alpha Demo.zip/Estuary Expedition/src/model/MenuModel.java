package model;

public class MenuModel {
	

	public MenuModel() {
		// TODO Auto-generated constructor stub
	}

}
