package model;

public class CubeModel {

	
	
	
	
	
	
}
