package model;

public class Obstacle {

	public Obstacle() {
		// TODO Auto-generated constructor stub
	}

}
