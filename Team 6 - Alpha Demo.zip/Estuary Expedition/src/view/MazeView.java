package view;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextArea;

import controller.MazeController;
import model.Player;

public class MazeView extends MazeController{
	int buttonWidth = 50;
	int buttonHeight = 50;
	int frameWidth = 1280;
	int frameHeight = 800;
	String playerIcon;
	String salinity;
	String timer;
	
	JTextArea holder = new JTextArea ("Work in Progress :)");
	
	JButton backButton;
	public JButton getBackButton() {
		return backButton;
	}


	public MazeView(){
		super();
		
		backButton = new JButton ("Exit");
		backButton.setSize(buttonWidth, buttonHeight);
		backButton.setLocation(0, 0);
		
		//holder.setSize(200, 50);
		//holder.setLocation(200, 200);
		
		playerIcon = "Game Files/bluecrab_back.png";
		salinity = "Game Files/SalinityMeter.png";
		timer = "Game Files/timer.png";
	}
	
	public void draw(Graphics g){
		try {
		BufferedImage icon;
		BufferedImage salt;
		BufferedImage clock;
			BufferedImage background = ImageIO.read(new File("Game Files/MazeIntro.png"));
			g.drawImage(background, 0, 0, null);
			
			icon = ImageIO.read(new File(playerIcon));
			salt = ImageIO.read(new File(salinity));
			clock = ImageIO.read(new File(timer));
			
			g.drawImage(icon, this.maze.player.getxCoord() , this.maze.player.getyCoord(), null);
			g.drawImage(salt, 1175 , 475, null);
			g.drawImage(clock, 975 , 10, null);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
