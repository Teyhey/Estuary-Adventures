package view;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JTextArea;

import controller.CubeController;

public class CubeView extends CubeController {

	int buttonWidth = 50;
	int buttonHeight = 50;
	int frameWidth = 1280;
	int frameHeight = 800;
	int randomPic;
	int arraySpot;
	String[] dicePics = { "Game Files/DeadFish.jpg", "Game Files/DogPoop.jpg", "Game Files/Heart.jpg",
			"Game Files/RoofGuy.jpg", "Game Files/Wizzel.jpg", "Game Files/Crab.jpg", "Game Files/Chicken.jpg" };
	String dice1;
	String dice2;
	String dice3;
	Random rand = new Random();

	JButton backButton;
	JButton roll;

	public JButton getBackButton() {
		return backButton;
	}

	public JButton getRoll(){
		return roll;
	}
	
	
	JTextArea holder = new JTextArea("THIS IS THE CUBE GAME");

	public CubeView() {
		super();
		backButton = new JButton("Exit");
		backButton.setSize(buttonWidth, buttonHeight);
		backButton.setLocation(0, 0);
		
		roll = new JButton("Roll");
		roll.setSize(buttonWidth, buttonHeight);
		roll.setLocation(30, 50);
		
		//holder.setSize(200, 200);
		//holder.setLocation(200, 200);

		randomize();

	}

	public void randomize(){
		randomPic = rand.nextInt(dicePics.length - 1) + 0;
		dice1 = dicePics[randomPic];
		randomPic = rand.nextInt(dicePics.length - 1) + 0;
		dice2 = dicePics[randomPic];
		randomPic = rand.nextInt(dicePics.length - 1) + 0;
		dice3 = dicePics[randomPic];
	}
	
	
	public void draw(Graphics g) {
		try {
			BufferedImage diceUno;
			BufferedImage diceDos;
			BufferedImage diceTres;
			BufferedImage background = ImageIO.read(new File("Game Files/2D_estuary.jpg"));
			g.drawImage(background, 0, 0, null);

			diceUno = ImageIO.read(new File(dice1));
			diceDos = ImageIO.read(new File(dice2));
			diceTres = ImageIO.read(new File(dice3));

			g.drawImage(diceUno, 100, 100, null);
			g.drawImage(diceDos, 500, 100, null);
			g.drawImage(diceTres, 900, 100, null);

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
