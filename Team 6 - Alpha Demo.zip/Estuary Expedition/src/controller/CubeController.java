package controller;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import model.CubeModel;

public class CubeController implements KeyListener{
	public CubeModel cubed;
	
	public CubeController(){
		cubed = new CubeModel();
	}
	
	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

}
