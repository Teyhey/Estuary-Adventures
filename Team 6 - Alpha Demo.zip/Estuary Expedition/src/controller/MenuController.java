package controller;

public class MenuController {

	public MenuController() {
		// TODO Auto-generated constructor stub
	}

}
